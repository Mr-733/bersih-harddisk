#!/bin/sh
./halo --setup
